package com.example.pingplan_makaylalmeeks;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class SmsActivity extends AppCompatActivity {

    // Emulator destination; for real devices use a proper +countrycode phone number (e.g., +15551234567).
    private static final String EMULATOR_NUMBER = "5554";

    private DatabaseHelper db;
    private TextView tvStatus;
    private final DateFormat timeFmt = DateFormat.getTimeInstance(DateFormat.SHORT);

    private final ActivityResultLauncher<String> smsPermLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    sendTodaysEventSms();
                } else {
                    tvStatus.setText(getString(R.string.permission_denied_sms));
                    Toast.makeText(this, R.string.permission_denied_sms_toast, Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        db = new DatabaseHelper(this);
        tvStatus = findViewById(R.id.tvSmsStatus);
        Button btn = findViewById(R.id.btnRequestSmsPermission);

        btn.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendTodaysEventSms();
            } else {
                smsPermLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });
    }

    /** Builds a summary of today's events and sends it via SMS (or updates UI on failure). */
    private void sendTodaysEventSms() {
        List<Event> today = db.getTodayEvents();
        if (today.isEmpty()) {
            tvStatus.setText(getString(R.string.no_events_today));
            return;
        }

        StringBuilder list = new StringBuilder();
        for (int i = 0; i < today.size(); i++) {
            Event e = today.get(i);
            if (i > 0) list.append("; ");
            list.append(e.title)
                    .append(" @ ")
                    .append(timeFmt.format(new Date(e.whenMillis)));
            if (e.location != null && !e.location.isEmpty()) {
                list.append(" (").append(e.location).append(")");
            }
        }
        String body = getString(R.string.todays_events_prefix, list.toString());

        try {
            SmsManager smsManager = getSystemService(SmsManager.class); // available on API 23+
            if (smsManager == null) {
                tvStatus.setText(getString(R.string.sms_failed, body));
                return;
            }
            smsManager.sendTextMessage(EMULATOR_NUMBER, null, body, null, null);
            tvStatus.setText(getString(R.string.sms_sent, body));
        } catch (Exception e) {
            tvStatus.setText(getString(R.string.sms_failed, body));
        }
    }
}
