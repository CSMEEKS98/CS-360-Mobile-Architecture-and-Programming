package com.example.pingplan_makaylalmeeks;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity implements EventAdapter.RowEvents {
    private DatabaseHelper db;
    private EventAdapter adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_database);

        db = new DatabaseHelper(this);

        RecyclerView rv = findViewById(R.id.rvGrid);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(db.getUpcomingEvents(), this);
        rv.setAdapter(adapter);

        findViewById(R.id.btnAdd).setOnClickListener(v -> showAddOrEditDialog(null));
    }

    // ---------- RowEvents ----------
    @Override public void onEdit(Event e) { showAddOrEditDialog(e); }

    @Override
    public void onDelete(Event e) {
        int rows = db.deleteEvent(e.id);
        Toast.makeText(MainActivity.this, rows > 0 ? "Event deleted" : "Delete failed",
                Toast.LENGTH_SHORT).show();
        adapter.replace(db.getUpcomingEvents());
    }


    // ---------- Add/Edit dialog with Date+Time pickers ----------
    private void showAddOrEditDialog(Event existing) {
        final EditText etTitle = new EditText(this);    etTitle.setHint("Title");
        final EditText etLocation = new EditText(this); etLocation.setHint("Location (optional)");
        final EditText etNotes = new EditText(this);    etNotes.setHint("Notes (optional)");
        etNotes.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        final java.util.Calendar cal = java.util.Calendar.getInstance();
        if (existing != null) cal.setTimeInMillis(existing.whenMillis);

        // Pre-fill if editing
        if (existing != null) {
            etTitle.setText(existing.title);
            etLocation.setText(existing.location);
            etNotes.setText(existing.notes);
        }

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        box.addView(etTitle); box.addView(etLocation); box.addView(etNotes);

        new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Add Event" : "Edit Event")
                .setView(box)
                .setPositiveButton("Pick Date/Time", (dlg, w) -> {
                    // DATE then TIME, then read the text fields and save/update
                    new DatePickerDialog(this, (view, y, m, d) -> {
                        cal.set(y, m, d);
                        new TimePickerDialog(this, (tv, h, min) -> {
                            cal.set(java.util.Calendar.HOUR_OF_DAY, h);
                            cal.set(java.util.Calendar.MINUTE, min);
                            long when = cal.getTimeInMillis();

                            // Read values HERE (inside the callback scope)
                            String title = etTitle.getText().toString().trim();
                            String loc   = etLocation.getText().toString().trim();
                            String notes = etNotes.getText().toString().trim();

                            if (existing == null) {
                                long id = db.insertEvent(title, when, loc, notes);
                                Toast.makeText(MainActivity.this,
                                        id != -1 ? "Event saved" : "Save failed",
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                int rows = db.updateEvent(existing.id, title, when, loc, notes);
                                Toast.makeText(MainActivity.this,
                                        rows > 0 ? "Event updated" : "Update failed",
                                        Toast.LENGTH_SHORT).show();
                            }
                            adapter.replace(db.getUpcomingEvents());
                        }, cal.get(java.util.Calendar.HOUR_OF_DAY),
                                cal.get(java.util.Calendar.MINUTE), false).show();
                    }, cal.get(java.util.Calendar.YEAR),
                            cal.get(java.util.Calendar.MONTH),
                            cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }


    // ---------- Overflow menu (SMS Alerts screen) ----------
    @Override public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_sms) {
            startActivity(new Intent(this, SmsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
