package com.example.pingplan_makaylalmeeks;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper db;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);

        EditText etUser = findViewById(R.id.etUsername);
        EditText etPass = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreateAccount);

        btnCreate.setOnClickListener(v -> {
            boolean ok = db.createUser(etUser.getText().toString().trim(), etPass.getText().toString());
            Toast.makeText(this, ok ? "Account created" : "User exists", Toast.LENGTH_SHORT).show();
        });

        btnLogin.setOnClickListener(v -> {
            boolean ok = db.validateLogin(etUser.getText().toString().trim(), etPass.getText().toString());
            if (ok) startActivity(new Intent(this, MainActivity.class));
            else Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        });
    }
}
