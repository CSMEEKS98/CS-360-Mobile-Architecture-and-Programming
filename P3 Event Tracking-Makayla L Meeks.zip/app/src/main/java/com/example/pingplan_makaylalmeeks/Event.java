package com.example.pingplan_makaylalmeeks;

public class Event {
    public long id;
    public String title;
    public long whenMillis;
    public String location;
    public String notes;

    public Event(long id, String title, long whenMillis, String location, String notes) {
        this.id = id;
        this.title = title;
        this.whenMillis = whenMillis;
        this.location = location;
        this.notes = notes;
    }
}

