package com.example.pingplan_makaylalmeeks;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "ping plan.db";
    private static final int DB_VER = 1;

    public DatabaseHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VER); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE," +
                "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE events(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "when_millis INTEGER NOT NULL," +
                "location TEXT," +
                "notes TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS events");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    // ---------- Auth ----------
    public boolean createUser(String u, String p) {
        ContentValues cv = new ContentValues();
        cv.put("username", u); cv.put("password", p);
        return getWritableDatabase().insert("users", null, cv) != -1;
    }

    public boolean validateLogin(String u, String p) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{u, p});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // ---------- Events CRUD ----------
    public long insertEvent(String title, long whenMillis, String location, String notes) {
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("when_millis", whenMillis);
        cv.put("location", location);
        cv.put("notes", notes);
        return getWritableDatabase().insert("events", null, cv);
    }

    public int updateEvent(long id, String title, long whenMillis, String location, String notes) {
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("when_millis", whenMillis);
        cv.put("location", location);
        cv.put("notes", notes);
        return getWritableDatabase().update("events", cv, "id=?",
                new String[]{String.valueOf(id)});
    }

    public int deleteEvent(long id) {
        return getWritableDatabase().delete("events", "id=?",
                new String[]{String.valueOf(id)});
    }

    public List<Event> getUpcomingEvents() {
        long now = System.currentTimeMillis();
        ArrayList<Event> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,title,when_millis,location,notes FROM events " +
                        "WHERE when_millis>=? ORDER BY when_millis",
                new String[]{String.valueOf(now)});
        while (c.moveToNext()) {
            out.add(new Event(
                    c.getLong(0), c.getString(1), c.getLong(2),
                    c.getString(3), c.getString(4)));
        }
        c.close();
        return out;
    }

    public List<Event> getTodayEvents() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        long start = cal.getTimeInMillis();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        long end = cal.getTimeInMillis();

        ArrayList<Event> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,title,when_millis,location,notes FROM events " +
                        "WHERE when_millis>=? AND when_millis<? ORDER BY when_millis",
                new String[]{String.valueOf(start), String.valueOf(end)});
        while (c.moveToNext()) {
            out.add(new Event(
                    c.getLong(0), c.getString(1), c.getLong(2),
                    c.getString(3), c.getString(4)));
        }
        c.close();
        return out;
    }
}
