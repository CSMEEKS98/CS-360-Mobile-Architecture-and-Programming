package com.example.pingplan_makaylalmeeks;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.VH> {

    public interface RowEvents { void onEdit(Event e); void onDelete(Event e); }

    private List<Event> data;
    private final RowEvents events;
    private final DateFormat df =
            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);

    public EventAdapter(List<Event> data, RowEvents events) {
        // never hold a null list
        this.data = (data != null) ? data : new ArrayList<>();
        this.events = events;
    }

    /** Use DiffUtil instead of notifyDataSetChanged() */
    public void replace(List<Event> newData) {
        final List<Event> old = this.data;
        final List<Event> fresh = (newData != null) ? newData : new ArrayList<>();

        DiffUtil.DiffResult diff = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return old.size(); }
            @Override public int getNewListSize() { return fresh.size(); }

            @Override public boolean areItemsTheSame(int oldPos, int newPos) {
                return old.get(oldPos).id == fresh.get(newPos).id;
            }

            @Override public boolean areContentsTheSame(int oldPos, int newPos) {
                Event o = old.get(oldPos), n = fresh.get(newPos);
                return o.whenMillis == n.whenMillis
                        && eq(o.title, n.title)
                        && eq(o.location, n.location)
                        && eq(o.notes, n.notes);
            }
        });

        this.data = fresh;
        diff.dispatchUpdatesTo(this);
    }

    private static boolean eq(Object a, Object b) {
        return Objects.equals(a, b);
    }

    // Make VH public to satisfy visibility lint
    public static class VH extends RecyclerView.ViewHolder {
        TextView title, date, location;
        Button delete;
        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.tvItemName);
            date = v.findViewById(R.id.tvDate);
            location = v.findViewById(R.id.tvQuantity);
            delete = v.findViewById(R.id.btnDeleteRow);
        }
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int viewType) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_row, p, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Event e = data.get(pos);
        h.title.setText(e.title);
        h.date.setText(df.format(new Date(e.whenMillis)));
        h.location.setText(e.location == null ? "" : e.location);

        h.itemView.setOnClickListener(v -> events.onEdit(e));
        h.delete.setOnClickListener(v -> events.onDelete(e));
    }

    @Override public int getItemCount() { return data.size(); }
}
